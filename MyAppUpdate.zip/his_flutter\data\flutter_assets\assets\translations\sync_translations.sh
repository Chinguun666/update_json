#!/bin/bash

echo "START"

mn_json_file="../../assets/translations/mn-MN.json"
en_json_file="../../assets/translations//en-US.json"

function crawler() {
  find . -type f | while IFS= read -r file; do
    # Check if the file is a regular file
    if [ -f "$file" ]; then
      # # Read the file line by line
      while IFS= read -r line; do
        # foundedStr="$line" | grep -o '"[^"]*".tr'
        realStr=$(echo "$line" | grep -o '"[^"]*".tr')
        if [[ -n $realStr ]]; then
          # echo "$line" | grep -o '"[^"]*".tr'
          removedTR=$(echo $realStr | sed 's/\.tr//' | tr -d '"')
          converted_string=$(echo $removedTR | sed 's/_/ /g' | sed 's/\.tr//' | tr -d '"')
          if jq -e .${removedTR} ${mn_json_file} >/dev/null 2>&1; then
            echo "MN: Already exists"
          else
            jq --arg key "$removedTR" --arg value "$converted_string" '. + {($key): $value}' $mn_json_file >"temp.json" && mv "temp.json" $mn_json_file
            echo "Write to MN: $removedTR => $converted_string"
          fi

          if jq -e .${removedTR} ${en_json_file} >/dev/null 2>&1; then
            echo "EN: Already exists"
          else
            jq --arg key "$removedTR" --arg value "$converted_string" '. + {($key): $value}' $en_json_file >"temp.json" && mv "temp.json" $en_json_file
            echo "Write to EN: $removedTR => $converted_string"
          fi
        fi
      done <"$file"
    fi
  done
}

cd ../../lib/screens
echo "Current working directory: $(pwd)"

crawler

cd ../..lib/widgets
echo "Current working directory: $(pwd)"

crawler
# # Read the JSON file
# jq . ${json_file}
# Check if the key exists in the JSON file

# # # List all files in the current directory and its subdirectories

echo "DONE"
